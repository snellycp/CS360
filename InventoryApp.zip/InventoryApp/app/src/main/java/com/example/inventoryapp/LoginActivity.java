package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Find views by ID
        EditText usernameField = findViewById(R.id.usernameField);
        EditText passwordField = findViewById(R.id.passwordField);
        TextView errorText = findViewById(R.id.errorText);
        Button loginButton = findViewById(R.id.loginButton);
        Button createAccountButton = findViewById(R.id.createAccountButton);

        // Set up login button
        loginButton.setOnClickListener(v -> {
            String username = usernameField.getText().toString();
            String password = passwordField.getText().toString();

            if (username.equals("admin") && password.equals("password")) {
                errorText.setVisibility(TextView.GONE);
                startActivity(new Intent(LoginActivity.this, HomeActivity.class));
            } else {
                errorText.setText("Invalid username or password.");
                errorText.setVisibility(TextView.VISIBLE);
            }
        });

        // Set up create account button
        createAccountButton.setOnClickListener(v -> {
            Toast.makeText(this, "Account creation coming soon!", Toast.LENGTH_SHORT).show();
        });
    }
}
