package com.example.inventoryapp;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class HomeActivity extends AppCompatActivity {

    private ArrayList<String> dataList;
    private DataAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        RecyclerView recyclerView = findViewById(R.id.dataRecyclerView);
        Button addDataButton = findViewById(R.id.addDataButton);

        // Initialize data list
        dataList = new ArrayList<>();
        dataList.add("Item 1");
        dataList.add("Item 2");

        // Set up RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new DataAdapter(dataList);
        recyclerView.setAdapter(adapter);

        // Add new data on button click
        addDataButton.setOnClickListener(v -> {
            dataList.add("New Item " + (dataList.size() + 1));
            adapter.notifyItemInserted(dataList.size() - 1);
        });
    }
}
